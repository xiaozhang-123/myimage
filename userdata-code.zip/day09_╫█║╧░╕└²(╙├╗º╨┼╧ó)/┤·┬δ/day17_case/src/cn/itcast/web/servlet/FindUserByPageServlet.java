package cn.itcast.web.servlet;

import cn.itcast.domain.PageBean;
import cn.itcast.domain.User;
import cn.itcast.service.UserService;
import cn.itcast.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@WebServlet("/findUserByPageServlet")
public class FindUserByPageServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");

        //1.获取参数
        String currentPage = request.getParameter("currentPage");//当前页码
        String rows = request.getParameter("rows");//每页显示条数

        if(currentPage == null || "".equals(currentPage)){//没有设置，就默认第一页

            currentPage = "1";
        }


        if(rows == null || "".equals(rows)){//没有设置，就弄5条
            rows = "5";
        }
        
        //获取条件查询参数
        Map<String, String[]> condition = request.getParameterMap();


        //2.调用service查询
        UserService service = new UserServiceImpl();//调用数据库访问方法
        PageBean<User> pb = service.findUserByPage(currentPage,rows,condition);//当前第几页
//这里是传进去当前第几页，还有这一页有多少个 数据，还有蕴含的数据项，然后传进去，先计算出有多少个数据项，然后的话，再传进去那一页有的对象，然后的话封装成对象
        System.out.println(pb);

        //3.将PageBean存入request
        request.setAttribute("pb",pb);//将页数对象放入数据session
        request.setAttribute("condition",condition);//将查询条件存入request
        //4.转发到list.jsp
        request.getRequestDispatcher("/list.jsp").forward(request,response);//存入数锯再弄成英文。，这就返回
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
