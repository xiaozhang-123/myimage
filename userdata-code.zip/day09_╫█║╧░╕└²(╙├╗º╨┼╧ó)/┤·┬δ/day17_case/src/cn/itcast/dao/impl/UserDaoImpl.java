package cn.itcast.dao.impl;

import cn.itcast.dao.UserDao;
import cn.itcast.domain.User;
import cn.itcast.util.JDBCUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class UserDaoImpl implements UserDao {//这个负责对数据方法库，各自写数据库的调用就行了

    private JdbcTemplate template = new JdbcTemplate(JDBCUtils.getDataSource());//工具库

    @Override
    public List<User> findAll() {
        //使用JDBC操作数据库...
        //1.定义sql
        String sql = "select * from user";
        List<User> users = template.query(sql, new BeanPropertyRowMapper<User>(User.class));
//将返回结果封装起来成集合
        return users;
    }

    @Override
    public User findUserByUsernameAndPassword(String username, String password) {//根据账号寻找数据库里面的账户
        try {
            String sql = "select * from user where username = ? and password = ?";
            User user = template.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class), username, password);
            return user;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    @Override
    public void add(User user) {//增
        //1.定义sql
        String sql = "insert into user values(null,?,?,?,?,?,?,null,null)";
        //2.执行sql
        template.update(sql, user.getName(), user.getGender(), user.getAge(), user.getAddress(), user.getQq(), user.getEmail());//这个可以自动添加数据
    }

    @Override
    public void delete(int id) {//删
        //1.定义sql
        String sql = "delete from user where id = ?";
        //2.执行sql
        template.update(sql, id);
    }

    @Override
    public User findById(int id) {//每一个对象以它的id为对象，用这个查找
        String sql = "select * from user where id = ?";
        return template.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class), id);
    }

    @Override
    public void update(User user) {//更新数据
        String sql = "update user set name = ?,gender = ? ,age = ? , address = ? , qq = ?, email = ? where id = ?";
        template.update(sql, user.getName(), user.getGender(), user.getAge(), user.getAddress(), user.getQq(), user.getEmail(), user.getId());
    }

    @Override
    public int findTotalCount(Map<String, String[]> condition) {//计算一共多少个
        //1.定义模板初始化sql
        String sql = "select count(*) from user where 1 = 1 ";
        StringBuilder sb = new StringBuilder(sql);
        //2.遍历map
        Set<String> keySet = condition.keySet();
        //定义参数的集合
        List<Object> params = new ArrayList<Object>();
        for (String key : keySet) {

            //排除分页条件参数
            if("currentPage".equals(key) || "rows".equals(key)){
                continue;
            }

            //获取value
            String value = condition.get(key)[0];//一般一个对象存一个值
            //判断value是否有值
            if(value != null && !"".equals(value)){
                //有值
                sb.append(" and "+key+" like ? ");//这是添加数据库代码，添加筛选条件
                params.add("%"+value+"%");//？条件的值
            }
        }
        System.out.println(sb.toString());
        System.out.println(params);

        return template.queryForObject(sb.toString(),Integer.class,params.toArray());//进行数据库查询，然后根据这个对象把结构返回
        //装入值

    }

    @Override
    public List<User> findByPage(int start, int rows, Map<String, String[]> condition) {//返回截取的数据部分
        String sql = "select * from user  where 1 = 1 ";

        StringBuilder sb = new StringBuilder(sql);
        //2.遍历map
        Set<String> keySet = condition.keySet();
        //定义参数的集合
        List<Object> params = new ArrayList<Object>();//这其实就是一个形参列表，然后的话，存储mysql匹配的值（也就是条件），要与mysql的语句里面的？一一对应
        for (String key : keySet) {

            //排除分页条件参数
            if("currentPage".equals(key) || "rows".equals(key)){
                continue;
                //这里是还没找到对应的页，那就找下一页
            }

            //获取value
            String value = condition.get(key)[0];//找到这一项了，就在这里找到相对应的信息组
            //判断value是否有值
            if(value != null && !"".equals(value)){
                //有值
                sb.append(" and "+key+" like ? ");//里面的问号是等待传入的形参
                params.add("%"+value+"%");//？条件的值，正则匹配
            }//不为空了，那就把各自匹配项放进去 ，也就是key1 like x1,key2 like x2,key3 like x3
        }
//这里是取出数据项的映射进去匹配，防止空的出现
        //添加分页查询
        sb.append(" limit ?,? ");//限制行数
        //添加分页查询参数值
        params.add(start);//这里同步limit加上两个形参，要限制开头结尾
        params.add(rows);//所以这里也在形参列表里面也加上了
        sql = sb.toString();
        System.out.println(sql);
        System.out.println(params);//分页查询

        return template.query(sql,new BeanPropertyRowMapper<User>(User.class),params.toArray());//形参集合列表话
    }
    //totalcount-> seslect count(*) from user where name like ? and address like ?
    // list对象集合 -> select * from user where name like ? and address like ? limit ?,?
    //要Like，防止空的对象传进去
}
